Ini adalah isi file main.js untuk bot WA pid.claude.bot.
