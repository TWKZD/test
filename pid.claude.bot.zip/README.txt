Ini adalah isi file README.txt untuk bot WA pid.claude.bot.
